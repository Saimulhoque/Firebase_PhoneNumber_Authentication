package com.example.firebasephonenumberauthentication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Phone_Auth extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phone__auth);
    }
}